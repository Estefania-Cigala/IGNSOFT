﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentGo.Modelos
{
    public class Cliente
    {
        public string IDCliente { get; set; } // Número de Licencia
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string Telefono { get; set; }
        // Otros campos opcionales (Correo, Dirección)
    }
}
