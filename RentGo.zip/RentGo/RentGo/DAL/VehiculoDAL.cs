﻿using RentGo.Modelos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace RentGo.DAL
{
    public class VehiculoDAL
    {
        // Cadena de Conexión Local (¡Ajusta 'YourServerName' y el nombre de la BD!)
        // Esta cadena utiliza SQL Server Express con autenticación de Windows,
        // asumiendo que el archivo .mdf está en la carpeta de la aplicación (DataDirectory).
        private readonly string connectionString = "Data Source=(LocalDB)\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\RentGoDB.mdf;Integrated Security=True;Connect Timeout=30";

        // =========================================================================
        // 1. OBTENER TODOS LOS VEHÍCULOS (Read) - Usado para DataGridView
        // =========================================================================
        public List<Vehiculo> ObtenerTodos()
        {
            List<Vehiculo> vehiculos = new List<Vehiculo>();
            string query = "SELECT Placa, Marca, Modelo, Anio, Estado, PrecioPorDia FROM Vehiculos";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    try
                    {
                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();

                        while (reader.Read())
                        {
                            vehiculos.Add(new Vehiculo
                            {
                                Placa = reader["Placa"].ToString(),
                                Marca = reader["Marca"].ToString(),
                                Modelo = reader["Modelo"].ToString(),
                                Anio = Convert.ToInt32(reader["Anio"]),
                                Estado = reader["Estado"].ToString(),
                                PrecioPorDia = Convert.ToDecimal(reader["PrecioPorDia"])
                            });
                        }
                    }
                    catch (Exception ex)
                    {
                        // Manejo de error: Registrar en un archivo de log
                        // LogHelper.Log(ex.Message); 
                        MessageBox.Show("Error al cargar vehículos: " + ex.Message, "Error de Conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            return vehiculos;
        }

        // =========================================================================
        // 2. AGREGAR VEHÍCULO (Create)
        // =========================================================================
        public bool AgregarVehiculo(Vehiculo vehiculo)
        {
            string query = "INSERT INTO Vehiculos (Placa, Marca, Modelo, Anio, Estado, PrecioPorDia) VALUES (@Placa, @Marca, @Modelo, @Anio, @Estado, @PrecioPorDia)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Usar parámetros para prevenir inyección SQL
                    command.Parameters.AddWithValue("@Placa", vehiculo.Placa);
                    command.Parameters.AddWithValue("@Marca", vehiculo.Marca);
                    command.Parameters.AddWithValue("@Modelo", vehiculo.Modelo);
                    command.Parameters.AddWithValue("@Anio", vehiculo.Anio);
                    command.Parameters.AddWithValue("@Estado", "Disponible"); // Estado inicial
                    command.Parameters.AddWithValue("@PrecioPorDia", vehiculo.PrecioPorDia);

                    try
                    {
                        connection.Open();
                        // ExecuteNonQuery devuelve el número de filas afectadas (debe ser 1)
                        return command.ExecuteNonQuery() > 0;
                    }
                    catch (SqlException ex) when (ex.Number == 2627) // Código de error de clave única duplicada
                    {
                        MessageBox.Show("Error: La placa '" + vehiculo.Placa + "' ya existe en el sistema.", "Validación de Datos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                    catch (Exception ex)
                    {
                        // LogHelper.Log(ex.Message);
                        MessageBox.Show("Error al agregar el vehículo: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
        }

        // =========================================================================
        // 3. ACTUALIZAR VEHÍCULO (Update)
        // =========================================================================
        public bool ActualizarVehiculo(Vehiculo vehiculo)
        {
            string query = "UPDATE Vehiculos SET Marca = @Marca, Modelo = @Modelo, Anio = @Anio, Estado = @Estado, PrecioPorDia = @PrecioPorDia WHERE Placa = @Placa";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Marca", vehiculo.Marca);
                    command.Parameters.AddWithValue("@Modelo", vehiculo.Modelo);
                    command.Parameters.AddWithValue("@Anio", vehiculo.Anio);
                    command.Parameters.AddWithValue("@Estado", vehiculo.Estado);
                    command.Parameters.AddWithValue("@PrecioPorDia", vehiculo.PrecioPorDia);
                    command.Parameters.AddWithValue("@Placa", vehiculo.Placa); // Usado en la cláusula WHERE

                    try
                    {
                        connection.Open();
                        return command.ExecuteNonQuery() > 0;
                    }
                    catch (Exception ex)
                    {
                        // LogHelper.Log(ex.Message);
                        MessageBox.Show("Error al actualizar el vehículo: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
        }

        // =========================================================================
        // 4. ELIMINAR VEHÍCULO (Delete)
        // =========================================================================
        public bool EliminarVehiculo(string placa)
        {
            // Lógica: Verificar si está "Alquilado" antes de intentar eliminar
            if (ObtenerEstado(placa) == "Alquilado")
            {
                MessageBox.Show("No se puede eliminar un vehículo que está actualmente Alquilado.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            string query = "DELETE FROM Vehiculos WHERE Placa = @Placa";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Placa", placa);

                    try
                    {
                        connection.Open();
                        return command.ExecuteNonQuery() > 0;
                    }
                    catch (Exception ex)
                    {
                        // LogHelper.Log(ex.Message);
                        MessageBox.Show("Error al eliminar el vehículo: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
        }

        // =========================================================================
        // 5. OBTENER ESTADO (Ayuda para validación)
        // =========================================================================
        public string ObtenerEstado(string placa)
        {
            string estado = string.Empty;
            string query = "SELECT Estado FROM Vehiculos WHERE Placa = @Placa";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Placa", placa);

                    try
                    {
                        connection.Open();
                        object result = command.ExecuteScalar();
                        if (result != null)
                        {
                            estado = result.ToString();
                        }
                    }
                    catch (Exception ex)
                    {
                        // LogHelper.Log(ex.Message);
                    }
                }
            }
            return estado;
        }
    }
}
